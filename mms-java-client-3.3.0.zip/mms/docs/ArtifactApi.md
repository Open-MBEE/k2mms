# ArtifactApi

All URIs are relative to *https://localhost/alfresco/service*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteArtifact**](ArtifactApi.md#deleteArtifact) | **DELETE** /projects/{project_id}/refs/{ref_id}/artifacts/{artifact_id} | Delete artifact
[**deleteArtifactsInBatch**](ArtifactApi.md#deleteArtifactsInBatch) | **DELETE** /projects/{project_id}/refs/{ref_id}/artifacts | Delete artifact(s) in batch
[**getArtifact**](ArtifactApi.md#getArtifact) | **GET** /projects/{project_id}/refs/{ref_id}/artifacts/{artifact_id} | Get artifact
[**getArtifactHistory**](ArtifactApi.md#getArtifactHistory) | **GET** /projects/{project_id}/refs/{ref_id}/artifacts/{artifact_id}/commits | Get artifact history
[**getArtifacts**](ArtifactApi.md#getArtifacts) | **GET** /projects/{project_id}/refs/{ref_id}/artifacts | Get artifacts
[**getArtifactsInBatch**](ArtifactApi.md#getArtifactsInBatch) | **PUT** /projects/{project_id}/refs/{ref_id}/artifacts | Get artifact(s) in batch
[**postArtifact**](ArtifactApi.md#postArtifact) | **POST** /projects/{project_id}/refs/{ref_id}/artifacts | Create and/or update artifact


<a name="deleteArtifact"></a>
# **deleteArtifact**
> Artifacts deleteArtifact(projectId, refId, artifactId)

Delete artifact



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ArtifactApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ArtifactApi apiInstance = new ArtifactApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
String artifactId = "artifactId_example"; // String | artifact identifier
try {
    Artifacts result = apiInstance.deleteArtifact(projectId, refId, artifactId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ArtifactApi#deleteArtifact");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |
 **artifactId** | **String**| artifact identifier |

### Return type

[**Artifacts**](Artifacts.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="deleteArtifactsInBatch"></a>
# **deleteArtifactsInBatch**
> Artifacts deleteArtifactsInBatch(projectId, refId, body)

Delete artifact(s) in batch



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ArtifactApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ArtifactApi apiInstance = new ArtifactApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
Artifacts body = new Artifacts(); // Artifacts | 
try {
    Artifacts result = apiInstance.deleteArtifactsInBatch(projectId, refId, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ArtifactApi#deleteArtifactsInBatch");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |
 **body** | [**Artifacts**](Artifacts.md)|  |

### Return type

[**Artifacts**](Artifacts.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getArtifact"></a>
# **getArtifact**
> Artifacts getArtifact(projectId, refId, artifactId, depth, extended, commitId)

Get artifact



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ArtifactApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ArtifactApi apiInstance = new ArtifactApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
String artifactId = "artifactId_example"; // String | artifact identifier
Integer depth = 56; // Integer | 
Boolean extended = true; // Boolean | 
String commitId = "commitId_example"; // String | 
try {
    Artifacts result = apiInstance.getArtifact(projectId, refId, artifactId, depth, extended, commitId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ArtifactApi#getArtifact");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |
 **artifactId** | **String**| artifact identifier |
 **depth** | **Integer**|  | [optional]
 **extended** | **Boolean**|  | [optional]
 **commitId** | **String**|  | [optional]

### Return type

[**Artifacts**](Artifacts.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getArtifactHistory"></a>
# **getArtifactHistory**
> Commits getArtifactHistory(projectId, refId, artifactId)

Get artifact history



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ArtifactApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ArtifactApi apiInstance = new ArtifactApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
String artifactId = "artifactId_example"; // String | artifact identifier
try {
    Commits result = apiInstance.getArtifactHistory(projectId, refId, artifactId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ArtifactApi#getArtifactHistory");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |
 **artifactId** | **String**| artifact identifier |

### Return type

[**Commits**](Commits.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getArtifacts"></a>
# **getArtifacts**
> Artifacts getArtifacts(projectId, refId, commitId)

Get artifacts



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ArtifactApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ArtifactApi apiInstance = new ArtifactApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
String commitId = "commitId_example"; // String | 
try {
    Artifacts result = apiInstance.getArtifacts(projectId, refId, commitId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ArtifactApi#getArtifacts");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |
 **commitId** | **String**|  | [optional]

### Return type

[**Artifacts**](Artifacts.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getArtifactsInBatch"></a>
# **getArtifactsInBatch**
> Artifacts getArtifactsInBatch(projectId, refId, body, commitId)

Get artifact(s) in batch



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ArtifactApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ArtifactApi apiInstance = new ArtifactApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
Artifacts body = new Artifacts(); // Artifacts | 
String commitId = "commitId_example"; // String | 
try {
    Artifacts result = apiInstance.getArtifactsInBatch(projectId, refId, body, commitId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ArtifactApi#getArtifactsInBatch");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |
 **body** | [**Artifacts**](Artifacts.md)|  |
 **commitId** | **String**|  | [optional]

### Return type

[**Artifacts**](Artifacts.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="postArtifact"></a>
# **postArtifact**
> Artifacts postArtifact(projectId, refId, id, file, contentType, name, source, comment)

Create and/or update artifact



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ArtifactApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ArtifactApi apiInstance = new ArtifactApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
String id = "id_example"; // String | 
File file = new File("/path/to/file.txt"); // File | 
String contentType = "contentType_example"; // String | When the content type cannot be automatically detected, this explicitly defined value is used.
String name = "name_example"; // String | 
String source = "source_example"; // String | 
String comment = "comment_example"; // String | 
try {
    Artifacts result = apiInstance.postArtifact(projectId, refId, id, file, contentType, name, source, comment);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ArtifactApi#postArtifact");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |
 **id** | **String**|  |
 **file** | **File**|  |
 **contentType** | **String**| When the content type cannot be automatically detected, this explicitly defined value is used. | [optional]
 **name** | **String**|  | [optional]
 **source** | **String**|  | [optional]
 **comment** | **String**|  | [optional]

### Return type

[**Artifacts**](Artifacts.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: Not defined

