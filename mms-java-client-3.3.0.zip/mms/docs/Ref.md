
# Ref

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**name** | **String** |  | 
**parentRefId** | **String** |  |  [optional]
**type** | [**TypeEnum**](#TypeEnum) |  | 


<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
BRANCH | &quot;Branch&quot;
TAG | &quot;Tag&quot;



