# RefApi

All URIs are relative to *https://localhost/alfresco/service*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteRef**](RefApi.md#deleteRef) | **DELETE** /projects/{project_id}/refs/{ref_id} | Delete ref
[**getRef**](RefApi.md#getRef) | **GET** /projects/{project_id}/refs/{ref_id} | Get ref
[**getRefHistory**](RefApi.md#getRefHistory) | **GET** /projects/{project_id}/refs/{ref_id}/commits | Get ref history
[**getRefs**](RefApi.md#getRefs) | **GET** /projects/{project_id}/refs | Get all refs in project
[**postRefs**](RefApi.md#postRefs) | **POST** /projects/{project_id}/refs | Create and/or update ref(s)


<a name="deleteRef"></a>
# **deleteRef**
> Refs deleteRef(projectId, refId)

Delete ref



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.RefApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

RefApi apiInstance = new RefApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
try {
    Refs result = apiInstance.deleteRef(projectId, refId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RefApi#deleteRef");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |

### Return type

[**Refs**](Refs.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getRef"></a>
# **getRef**
> Refs getRef(projectId, refId)

Get ref



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.RefApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

RefApi apiInstance = new RefApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
try {
    Refs result = apiInstance.getRef(projectId, refId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RefApi#getRef");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |

### Return type

[**Refs**](Refs.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getRefHistory"></a>
# **getRefHistory**
> Commits getRefHistory(projectId, refId)

Get ref history



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.RefApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

RefApi apiInstance = new RefApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
try {
    Commits result = apiInstance.getRefHistory(projectId, refId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RefApi#getRefHistory");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |

### Return type

[**Commits**](Commits.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getRefs"></a>
# **getRefs**
> Refs getRefs(projectId)

Get all refs in project



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.RefApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

RefApi apiInstance = new RefApi();
String projectId = "projectId_example"; // String | project identifier
try {
    Refs result = apiInstance.getRefs(projectId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RefApi#getRefs");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |

### Return type

[**Refs**](Refs.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="postRefs"></a>
# **postRefs**
> Refs postRefs(projectId, body)

Create and/or update ref(s)



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.RefApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

RefApi apiInstance = new RefApi();
String projectId = "projectId_example"; // String | project identifier
Refs body = new Refs(); // Refs | 
try {
    Refs result = apiInstance.postRefs(projectId, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RefApi#postRefs");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **body** | [**Refs**](Refs.md)|  |

### Return type

[**Refs**](Refs.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

