
# Orgs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orgs** | [**List&lt;Org&gt;**](Org.md) |  | 



