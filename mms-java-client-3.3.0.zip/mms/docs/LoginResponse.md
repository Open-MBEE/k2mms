
# LoginResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**LoginResponseData**](LoginResponseData.md) |  | 



