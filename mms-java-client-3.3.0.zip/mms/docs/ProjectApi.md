# ProjectApi

All URIs are relative to *https://localhost/alfresco/service*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteProject**](ProjectApi.md#deleteProject) | **DELETE** /projects/{project_id} | Delete project
[**getProject**](ProjectApi.md#getProject) | **GET** /projects/{project_id} | Get project
[**getProjectCommit**](ProjectApi.md#getProjectCommit) | **GET** /projects/{project_id}/commits/{commit_id} | Get project commit
[**getProjects**](ProjectApi.md#getProjects) | **GET** /projects | Get all projects
[**getProjectsByOrg**](ProjectApi.md#getProjectsByOrg) | **GET** /orgs/{org_id}/projects | Get all projects in org
[**postProjects**](ProjectApi.md#postProjects) | **POST** /projects | Create and/or update project(s)
[**postProjectsByOrg**](ProjectApi.md#postProjectsByOrg) | **POST** /orgs/{org_id}/projects | Create and/or update project(s) in org


<a name="deleteProject"></a>
# **deleteProject**
> Projects deleteProject(projectId)

Delete project



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProjectApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ProjectApi apiInstance = new ProjectApi();
String projectId = "projectId_example"; // String | project identifier
try {
    Projects result = apiInstance.deleteProject(projectId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProjectApi#deleteProject");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |

### Return type

[**Projects**](Projects.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getProject"></a>
# **getProject**
> Projects getProject(projectId)

Get project



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProjectApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ProjectApi apiInstance = new ProjectApi();
String projectId = "projectId_example"; // String | project identifier
try {
    Projects result = apiInstance.getProject(projectId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProjectApi#getProject");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |

### Return type

[**Projects**](Projects.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getProjectCommit"></a>
# **getProjectCommit**
> Commits getProjectCommit(projectId, commitId)

Get project commit



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProjectApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ProjectApi apiInstance = new ProjectApi();
String projectId = "projectId_example"; // String | project identifier
String commitId = "commitId_example"; // String | commit identifier
try {
    Commits result = apiInstance.getProjectCommit(projectId, commitId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProjectApi#getProjectCommit");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **commitId** | **String**| commit identifier |

### Return type

[**Commits**](Commits.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getProjects"></a>
# **getProjects**
> Projects getProjects()

Get all projects



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProjectApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ProjectApi apiInstance = new ProjectApi();
try {
    Projects result = apiInstance.getProjects();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProjectApi#getProjects");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Projects**](Projects.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getProjectsByOrg"></a>
# **getProjectsByOrg**
> Projects getProjectsByOrg(orgId)

Get all projects in org



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProjectApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ProjectApi apiInstance = new ProjectApi();
String orgId = "orgId_example"; // String | org identifier
try {
    Projects result = apiInstance.getProjectsByOrg(orgId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProjectApi#getProjectsByOrg");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orgId** | **String**| org identifier |

### Return type

[**Projects**](Projects.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="postProjects"></a>
# **postProjects**
> Projects postProjects(body)

Create and/or update project(s)



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProjectApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ProjectApi apiInstance = new ProjectApi();
Projects body = new Projects(); // Projects | 
try {
    Projects result = apiInstance.postProjects(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProjectApi#postProjects");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Projects**](Projects.md)|  |

### Return type

[**Projects**](Projects.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="postProjectsByOrg"></a>
# **postProjectsByOrg**
> Projects postProjectsByOrg(orgId, body)

Create and/or update project(s) in org



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProjectApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ProjectApi apiInstance = new ProjectApi();
String orgId = "orgId_example"; // String | org identifier
Projects body = new Projects(); // Projects | 
try {
    Projects result = apiInstance.postProjectsByOrg(orgId, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProjectApi#postProjectsByOrg");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orgId** | **String**| org identifier |
 **body** | [**Projects**](Projects.md)|  |

### Return type

[**Projects**](Projects.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

