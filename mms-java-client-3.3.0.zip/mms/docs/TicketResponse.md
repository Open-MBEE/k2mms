
# TicketResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** |  | 
**first** | **String** |  | 
**last** | **String** |  | 



