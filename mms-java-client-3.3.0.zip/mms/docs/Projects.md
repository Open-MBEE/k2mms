
# Projects

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**projects** | [**List&lt;Project&gt;**](Project.md) |  | 



