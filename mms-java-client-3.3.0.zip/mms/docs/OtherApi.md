# OtherApi

All URIs are relative to *https://localhost/alfresco/service*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getDocuments**](OtherApi.md#getDocuments) | **GET** /projects/{project_id}/refs/{ref_id}/documents | Get documents
[**getGroups**](OtherApi.md#getGroups) | **GET** /projects/{project_id}/refs/{ref_id}/groups | Get groups
[**getMounts**](OtherApi.md#getMounts) | **GET** /projects/{project_id}/refs/{ref_id}/mounts | Get mounts


<a name="getDocuments"></a>
# **getDocuments**
> Documents getDocuments(projectId, refId)

Get documents



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OtherApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

OtherApi apiInstance = new OtherApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
try {
    Documents result = apiInstance.getDocuments(projectId, refId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OtherApi#getDocuments");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |

### Return type

[**Documents**](Documents.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getGroups"></a>
# **getGroups**
> Groups getGroups(projectId, refId)

Get groups



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OtherApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

OtherApi apiInstance = new OtherApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
try {
    Groups result = apiInstance.getGroups(projectId, refId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OtherApi#getGroups");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |

### Return type

[**Groups**](Groups.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getMounts"></a>
# **getMounts**
> Mounts getMounts(projectId, refId)

Get mounts



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OtherApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

OtherApi apiInstance = new OtherApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
try {
    Mounts result = apiInstance.getMounts(projectId, refId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OtherApi#getMounts");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |

### Return type

[**Mounts**](Mounts.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

