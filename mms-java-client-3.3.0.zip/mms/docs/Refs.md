
# Refs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**refs** | [**List&lt;Ref&gt;**](Ref.md) |  | 



