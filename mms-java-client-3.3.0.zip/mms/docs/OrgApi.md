# OrgApi

All URIs are relative to *https://localhost/alfresco/service*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteOrg**](OrgApi.md#deleteOrg) | **DELETE** /orgs/{org_id} | Delete org
[**getOrg**](OrgApi.md#getOrg) | **GET** /orgs/{org_id} | Get org
[**getOrgs**](OrgApi.md#getOrgs) | **GET** /orgs | Get all orgs
[**postOrgs**](OrgApi.md#postOrgs) | **POST** /orgs | Create and/or update org(s)


<a name="deleteOrg"></a>
# **deleteOrg**
> Orgs deleteOrg(orgId)

Delete org



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrgApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

OrgApi apiInstance = new OrgApi();
String orgId = "orgId_example"; // String | org identifier
try {
    Orgs result = apiInstance.deleteOrg(orgId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrgApi#deleteOrg");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orgId** | **String**| org identifier |

### Return type

[**Orgs**](Orgs.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getOrg"></a>
# **getOrg**
> Orgs getOrg(orgId)

Get org



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrgApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

OrgApi apiInstance = new OrgApi();
String orgId = "orgId_example"; // String | org identifier
try {
    Orgs result = apiInstance.getOrg(orgId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrgApi#getOrg");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orgId** | **String**| org identifier |

### Return type

[**Orgs**](Orgs.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getOrgs"></a>
# **getOrgs**
> Orgs getOrgs()

Get all orgs



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrgApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

OrgApi apiInstance = new OrgApi();
try {
    Orgs result = apiInstance.getOrgs();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrgApi#getOrgs");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Orgs**](Orgs.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="postOrgs"></a>
# **postOrgs**
> Orgs postOrgs(body)

Create and/or update org(s)



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrgApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

OrgApi apiInstance = new OrgApi();
Orgs body = new Orgs(); // Orgs | 
try {
    Orgs result = apiInstance.postOrgs(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrgApi#postOrgs");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Orgs**](Orgs.md)|  |

### Return type

[**Orgs**](Orgs.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

