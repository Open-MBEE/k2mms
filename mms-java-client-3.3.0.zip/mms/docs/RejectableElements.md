
# RejectableElements

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**elements** | [**List&lt;Element&gt;**](Element.md) |  | 
**rejected** | [**List&lt;Rejection&gt;**](Rejection.md) |  |  [optional]
**comment** | **String** |  |  [optional]
**source** | **String** |  |  [optional]



