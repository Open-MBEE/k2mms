
# Elements

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**elements** | [**List&lt;Element&gt;**](Element.md) |  | 
**comment** | **String** |  |  [optional]
**source** | **String** |  |  [optional]



