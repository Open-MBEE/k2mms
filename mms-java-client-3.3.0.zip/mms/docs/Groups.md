
# Groups

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groups** | [**List&lt;Element&gt;**](Element.md) |  | 



