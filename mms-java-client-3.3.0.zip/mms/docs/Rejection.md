
# Rejection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | [**BigDecimal**](BigDecimal.md) |  | 
**id** | **String** |  |  [optional]
**element** | [**Element**](Element.md) |  |  [optional]
**message** | **String** |  | 
**severity** | **String** |  | 



