
# Artifacts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artifacts** | [**List&lt;Artifact&gt;**](Artifact.md) |  | 



