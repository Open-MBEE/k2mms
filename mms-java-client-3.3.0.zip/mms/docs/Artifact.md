
# Artifact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**contentType** | **String** |  | 
**checksum** | **String** |  | 
**artifactLocation** | **String** |  | 
**name** | **String** |  |  [optional]



