# TicketApi

All URIs are relative to *https://localhost/alfresco/service*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getTicket**](TicketApi.md#getTicket) | **GET** /mms/login/ticket/{ticket_id} | Get ticket
[**postTicket**](TicketApi.md#postTicket) | **POST** /api/login | Create ticket


<a name="getTicket"></a>
# **getTicket**
> TicketResponse getTicket(ticketId)

Get ticket



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.TicketApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

TicketApi apiInstance = new TicketApi();
String ticketId = "ticketId_example"; // String | ticket identifier
try {
    TicketResponse result = apiInstance.getTicket(ticketId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TicketApi#getTicket");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ticketId** | **String**| ticket identifier |

### Return type

[**TicketResponse**](TicketResponse.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="postTicket"></a>
# **postTicket**
> LoginResponse postTicket(body)

Create ticket



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.TicketApi;


TicketApi apiInstance = new TicketApi();
LoginRequest body = new LoginRequest(); // LoginRequest | 
try {
    LoginResponse result = apiInstance.postTicket(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TicketApi#postTicket");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**LoginRequest**](LoginRequest.md)|  |

### Return type

[**LoginResponse**](LoginResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

