
# Mounts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mounts** | [**List&lt;Project&gt;**](Project.md) |  | 



