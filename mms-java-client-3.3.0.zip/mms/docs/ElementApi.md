# ElementApi

All URIs are relative to *https://localhost/alfresco/service*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteElement**](ElementApi.md#deleteElement) | **DELETE** /projects/{project_id}/refs/{ref_id}/elements/{element_id} | Delete element
[**deleteElementsInBatch**](ElementApi.md#deleteElementsInBatch) | **DELETE** /projects/{project_id}/refs/{ref_id}/elements | Delete element(s) in batch
[**getElement**](ElementApi.md#getElement) | **GET** /projects/{project_id}/refs/{ref_id}/elements/{element_id} | Get element
[**getElementHistory**](ElementApi.md#getElementHistory) | **GET** /projects/{project_id}/refs/{ref_id}/elements/{element_id}/commits | Get element history
[**getElements**](ElementApi.md#getElements) | **GET** /projects/{project_id}/refs/{ref_id}/elements | Get elements
[**getElementsInBatch**](ElementApi.md#getElementsInBatch) | **PUT** /projects/{project_id}/refs/{ref_id}/elements | Get element(s) in batch
[**postElements**](ElementApi.md#postElements) | **POST** /projects/{project_id}/refs/{ref_id}/elements | Create and/or update element(s)


<a name="deleteElement"></a>
# **deleteElement**
> Elements deleteElement(projectId, refId, elementId)

Delete element



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ElementApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ElementApi apiInstance = new ElementApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
String elementId = "elementId_example"; // String | element identifier
try {
    Elements result = apiInstance.deleteElement(projectId, refId, elementId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ElementApi#deleteElement");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |
 **elementId** | **String**| element identifier |

### Return type

[**Elements**](Elements.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="deleteElementsInBatch"></a>
# **deleteElementsInBatch**
> Elements deleteElementsInBatch(projectId, refId, body)

Delete element(s) in batch



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ElementApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ElementApi apiInstance = new ElementApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
Elements body = new Elements(); // Elements | 
try {
    Elements result = apiInstance.deleteElementsInBatch(projectId, refId, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ElementApi#deleteElementsInBatch");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |
 **body** | [**Elements**](Elements.md)|  |

### Return type

[**Elements**](Elements.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getElement"></a>
# **getElement**
> Elements getElement(projectId, refId, elementId, depth, extended, commitId)

Get element



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ElementApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ElementApi apiInstance = new ElementApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
String elementId = "elementId_example"; // String | element identifier
Integer depth = 56; // Integer | 
Boolean extended = true; // Boolean | 
String commitId = "commitId_example"; // String | 
try {
    Elements result = apiInstance.getElement(projectId, refId, elementId, depth, extended, commitId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ElementApi#getElement");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |
 **elementId** | **String**| element identifier |
 **depth** | **Integer**|  | [optional]
 **extended** | **Boolean**|  | [optional]
 **commitId** | **String**|  | [optional]

### Return type

[**Elements**](Elements.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getElementHistory"></a>
# **getElementHistory**
> Commits getElementHistory(projectId, refId, elementId)

Get element history



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ElementApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ElementApi apiInstance = new ElementApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
String elementId = "elementId_example"; // String | element identifier
try {
    Commits result = apiInstance.getElementHistory(projectId, refId, elementId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ElementApi#getElementHistory");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |
 **elementId** | **String**| element identifier |

### Return type

[**Commits**](Commits.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getElements"></a>
# **getElements**
> Elements getElements(projectId, refId, extended, commitId)

Get elements



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ElementApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ElementApi apiInstance = new ElementApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
Boolean extended = true; // Boolean | 
String commitId = "commitId_example"; // String | 
try {
    Elements result = apiInstance.getElements(projectId, refId, extended, commitId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ElementApi#getElements");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |
 **extended** | **Boolean**|  | [optional]
 **commitId** | **String**|  | [optional]

### Return type

[**Elements**](Elements.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getElementsInBatch"></a>
# **getElementsInBatch**
> RejectableElements getElementsInBatch(projectId, refId, body, depth, extended, commitId)

Get element(s) in batch



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ElementApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ElementApi apiInstance = new ElementApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
Elements body = new Elements(); // Elements | 
Integer depth = 56; // Integer | 
Boolean extended = true; // Boolean | 
String commitId = "commitId_example"; // String | 
try {
    RejectableElements result = apiInstance.getElementsInBatch(projectId, refId, body, depth, extended, commitId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ElementApi#getElementsInBatch");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |
 **body** | [**Elements**](Elements.md)|  |
 **depth** | **Integer**|  | [optional]
 **extended** | **Boolean**|  | [optional]
 **commitId** | **String**|  | [optional]

### Return type

[**RejectableElements**](RejectableElements.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="postElements"></a>
# **postElements**
> RejectableElements postElements(projectId, refId, body)

Create and/or update element(s)



### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ElementApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: Basic
HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
Basic.setUsername("YOUR USERNAME");
Basic.setPassword("YOUR PASSWORD");

// Configure API key authorization: Ticket
ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
Ticket.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Ticket.setApiKeyPrefix("Token");

ElementApi apiInstance = new ElementApi();
String projectId = "projectId_example"; // String | project identifier
String refId = "refId_example"; // String | ref identifier
Elements body = new Elements(); // Elements | 
try {
    RejectableElements result = apiInstance.postElements(projectId, refId, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ElementApi#postElements");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **String**| project identifier |
 **refId** | **String**| ref identifier |
 **body** | [**Elements**](Elements.md)|  |

### Return type

[**RejectableElements**](RejectableElements.md)

### Authorization

[Basic](../README.md#Basic), [Ticket](../README.md#Ticket)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

