
# LoginResponseData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ticket** | **String** |  | 



