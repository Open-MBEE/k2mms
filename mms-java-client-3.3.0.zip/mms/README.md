# swagger-java-client

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>io.swagger</groupId>
    <artifactId>swagger-java-client</artifactId>
    <version>1.0.0</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "io.swagger:swagger-java-client:1.0.0"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

* target/swagger-java-client-1.0.0.jar
* target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.ArtifactApi;

import java.io.File;
import java.util.*;

public class ArtifactApiExample {

    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        
        // Configure HTTP basic authorization: Basic
        HttpBasicAuth Basic = (HttpBasicAuth) defaultClient.getAuthentication("Basic");
        Basic.setUsername("YOUR USERNAME");
        Basic.setPassword("YOUR PASSWORD");

        // Configure API key authorization: Ticket
        ApiKeyAuth Ticket = (ApiKeyAuth) defaultClient.getAuthentication("Ticket");
        Ticket.setApiKey("YOUR API KEY");
        // Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
        //Ticket.setApiKeyPrefix("Token");

        ArtifactApi apiInstance = new ArtifactApi();
        String projectId = "projectId_example"; // String | project identifier
        String refId = "refId_example"; // String | ref identifier
        String artifactId = "artifactId_example"; // String | artifact identifier
        try {
            Artifacts result = apiInstance.deleteArtifact(projectId, refId, artifactId);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling ArtifactApi#deleteArtifact");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *https://localhost/alfresco/service*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*ArtifactApi* | [**deleteArtifact**](docs/ArtifactApi.md#deleteArtifact) | **DELETE** /projects/{project_id}/refs/{ref_id}/artifacts/{artifact_id} | Delete artifact
*ArtifactApi* | [**deleteArtifactsInBatch**](docs/ArtifactApi.md#deleteArtifactsInBatch) | **DELETE** /projects/{project_id}/refs/{ref_id}/artifacts | Delete artifact(s) in batch
*ArtifactApi* | [**getArtifact**](docs/ArtifactApi.md#getArtifact) | **GET** /projects/{project_id}/refs/{ref_id}/artifacts/{artifact_id} | Get artifact
*ArtifactApi* | [**getArtifactHistory**](docs/ArtifactApi.md#getArtifactHistory) | **GET** /projects/{project_id}/refs/{ref_id}/artifacts/{artifact_id}/commits | Get artifact history
*ArtifactApi* | [**getArtifacts**](docs/ArtifactApi.md#getArtifacts) | **GET** /projects/{project_id}/refs/{ref_id}/artifacts | Get artifacts
*ArtifactApi* | [**getArtifactsInBatch**](docs/ArtifactApi.md#getArtifactsInBatch) | **PUT** /projects/{project_id}/refs/{ref_id}/artifacts | Get artifact(s) in batch
*ArtifactApi* | [**postArtifact**](docs/ArtifactApi.md#postArtifact) | **POST** /projects/{project_id}/refs/{ref_id}/artifacts | Create and/or update artifact
*ElementApi* | [**deleteElement**](docs/ElementApi.md#deleteElement) | **DELETE** /projects/{project_id}/refs/{ref_id}/elements/{element_id} | Delete element
*ElementApi* | [**deleteElementsInBatch**](docs/ElementApi.md#deleteElementsInBatch) | **DELETE** /projects/{project_id}/refs/{ref_id}/elements | Delete element(s) in batch
*ElementApi* | [**getElement**](docs/ElementApi.md#getElement) | **GET** /projects/{project_id}/refs/{ref_id}/elements/{element_id} | Get element
*ElementApi* | [**getElementHistory**](docs/ElementApi.md#getElementHistory) | **GET** /projects/{project_id}/refs/{ref_id}/elements/{element_id}/commits | Get element history
*ElementApi* | [**getElements**](docs/ElementApi.md#getElements) | **GET** /projects/{project_id}/refs/{ref_id}/elements | Get elements
*ElementApi* | [**getElementsInBatch**](docs/ElementApi.md#getElementsInBatch) | **PUT** /projects/{project_id}/refs/{ref_id}/elements | Get element(s) in batch
*ElementApi* | [**postElements**](docs/ElementApi.md#postElements) | **POST** /projects/{project_id}/refs/{ref_id}/elements | Create and/or update element(s)
*OrgApi* | [**deleteOrg**](docs/OrgApi.md#deleteOrg) | **DELETE** /orgs/{org_id} | Delete org
*OrgApi* | [**getOrg**](docs/OrgApi.md#getOrg) | **GET** /orgs/{org_id} | Get org
*OrgApi* | [**getOrgs**](docs/OrgApi.md#getOrgs) | **GET** /orgs | Get all orgs
*OrgApi* | [**postOrgs**](docs/OrgApi.md#postOrgs) | **POST** /orgs | Create and/or update org(s)
*OtherApi* | [**getDocuments**](docs/OtherApi.md#getDocuments) | **GET** /projects/{project_id}/refs/{ref_id}/documents | Get documents
*OtherApi* | [**getGroups**](docs/OtherApi.md#getGroups) | **GET** /projects/{project_id}/refs/{ref_id}/groups | Get groups
*OtherApi* | [**getMounts**](docs/OtherApi.md#getMounts) | **GET** /projects/{project_id}/refs/{ref_id}/mounts | Get mounts
*ProjectApi* | [**deleteProject**](docs/ProjectApi.md#deleteProject) | **DELETE** /projects/{project_id} | Delete project
*ProjectApi* | [**getProject**](docs/ProjectApi.md#getProject) | **GET** /projects/{project_id} | Get project
*ProjectApi* | [**getProjectCommit**](docs/ProjectApi.md#getProjectCommit) | **GET** /projects/{project_id}/commits/{commit_id} | Get project commit
*ProjectApi* | [**getProjects**](docs/ProjectApi.md#getProjects) | **GET** /projects | Get all projects
*ProjectApi* | [**getProjectsByOrg**](docs/ProjectApi.md#getProjectsByOrg) | **GET** /orgs/{org_id}/projects | Get all projects in org
*ProjectApi* | [**postProjects**](docs/ProjectApi.md#postProjects) | **POST** /projects | Create and/or update project(s)
*ProjectApi* | [**postProjectsByOrg**](docs/ProjectApi.md#postProjectsByOrg) | **POST** /orgs/{org_id}/projects | Create and/or update project(s) in org
*RefApi* | [**deleteRef**](docs/RefApi.md#deleteRef) | **DELETE** /projects/{project_id}/refs/{ref_id} | Delete ref
*RefApi* | [**getRef**](docs/RefApi.md#getRef) | **GET** /projects/{project_id}/refs/{ref_id} | Get ref
*RefApi* | [**getRefHistory**](docs/RefApi.md#getRefHistory) | **GET** /projects/{project_id}/refs/{ref_id}/commits | Get ref history
*RefApi* | [**getRefs**](docs/RefApi.md#getRefs) | **GET** /projects/{project_id}/refs | Get all refs in project
*RefApi* | [**postRefs**](docs/RefApi.md#postRefs) | **POST** /projects/{project_id}/refs | Create and/or update ref(s)
*TicketApi* | [**getTicket**](docs/TicketApi.md#getTicket) | **GET** /mms/login/ticket/{ticket_id} | Get ticket
*TicketApi* | [**postTicket**](docs/TicketApi.md#postTicket) | **POST** /api/login | Create ticket


## Documentation for Models

 - [Artifact](docs/Artifact.md)
 - [Artifacts](docs/Artifacts.md)
 - [Commit](docs/Commit.md)
 - [Commits](docs/Commits.md)
 - [Documents](docs/Documents.md)
 - [Element](docs/Element.md)
 - [Elements](docs/Elements.md)
 - [Groups](docs/Groups.md)
 - [LoginRequest](docs/LoginRequest.md)
 - [LoginResponse](docs/LoginResponse.md)
 - [LoginResponseData](docs/LoginResponseData.md)
 - [Mounts](docs/Mounts.md)
 - [Org](docs/Org.md)
 - [Orgs](docs/Orgs.md)
 - [Project](docs/Project.md)
 - [Projects](docs/Projects.md)
 - [Ref](docs/Ref.md)
 - [Refs](docs/Refs.md)
 - [RejectableElements](docs/RejectableElements.md)
 - [Rejection](docs/Rejection.md)
 - [TicketResponse](docs/TicketResponse.md)


## Documentation for Authorization

Authentication schemes defined for the API:
### Basic

- **Type**: HTTP basic authentication

### Ticket

- **Type**: API key
- **API key parameter name**: alf_ticket
- **Location**: URL query string


## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issues.

## Author



